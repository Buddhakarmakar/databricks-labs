-- Databricks notebook source
-- This is an exploratory notebook. It is not executed as part of the pipeline.
-- Use it to explore data produced by the pipeline.

USE CATALOG `main`;
USE SCHEMA `default`;

SELECT * from sample_trips_4_adding_dlt_expectations;